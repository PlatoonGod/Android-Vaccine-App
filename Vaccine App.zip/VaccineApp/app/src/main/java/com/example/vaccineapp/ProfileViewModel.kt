// ProfileViewModel.kt
// ViewModel for managing user profile data

package com.example.vaccineapp

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class ProfileViewModel(private val dataStoreManager: DataStoreManager) : ViewModel() {
    var name = mutableStateOf("")
    var surname = mutableStateOf("")
    var age = mutableStateOf("")
    var gender = mutableStateOf(false)
    var emergencyContact = mutableStateOf("")
    var country = mutableStateOf("UK")

    init {
        loadUserData()
    }

    private fun loadUserData() {
        viewModelScope.launch {
            dataStoreManager.name.collect { value -> if (value != null) name.value = value }
            dataStoreManager.surname.collect { value -> if (value != null) surname.value = value }
            dataStoreManager.age.collect { value -> if (value != null) age.value = value }
            dataStoreManager.gender.collect { value -> if (value != null) gender.value = value }
            dataStoreManager.emergencyContact.collect { value -> if (value != null) emergencyContact.value = value }
            dataStoreManager.country.collect { value -> if (value != null) country.value = value }
        }
    }

    fun saveUserInputs(name: String, surname: String, age: String, gender: Boolean, emergencyContact: String) {
        this.name.value = name
        this.surname.value = surname
        this.age.value = age
        this.gender.value = gender
        this.emergencyContact.value = emergencyContact
        viewModelScope.launch {
            dataStoreManager.saveUserInputs(name, surname, age, gender, emergencyContact)
        }
    }

    fun onNameChange(newName: String) {
        name.value = newName
    }

    fun onSurnameChange(newSurname: String) {
        surname.value = newSurname
    }

    fun onAgeChange(newAge: String) {
        age.value = newAge
    }

    fun onGenderChange(newGender: Boolean) {
        gender.value = newGender
    }

    fun onEmergencyContactChange(newContact: String) {
        emergencyContact.value = newContact
    }
}
