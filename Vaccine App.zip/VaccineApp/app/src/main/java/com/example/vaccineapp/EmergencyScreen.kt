// EmergencyScreen.kt
// Handles the UI and functionality for emergency contacts and actions

package com.example.vaccineapp

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat.startActivity
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun EmergencyScreen(viewModel: ProfileViewModel = viewModel()) {
    val context = LocalContext.current
    Column(modifier = Modifier.padding(16.dp)) {
        // Call Section
        Text(text = "Call", fontSize = 24.sp, modifier = Modifier.padding(bottom = 8.dp))
        Button(onClick = { callNumber(context, "999") }, modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)) {
            Text("Police")
        }
        Button(onClick = { callNumber(context, "112") }, modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)) {
            Text("Ambulance")
        }
        Button(onClick = { callNumber(context, viewModel.emergencyContact.value) }, modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp)) {
            Text("Emergency Contact")
        }

        // Email Section
        Text(text = "Email", fontSize = 24.sp, modifier = Modifier.padding(bottom = 8.dp))
        Button(onClick = { sendEmail(context, "hospital@example.com") }, modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp)) {
            Text("Email Hospital")
        }

        // Nearest Hospital Section
        Text(text = "Nearest Hospital", fontSize = 24.sp, modifier = Modifier.padding(bottom = 8.dp))
        Button(onClick = { findNearestHospital(context) }, modifier = Modifier.fillMaxWidth()) {
            Text("Find Nearest Hospital")
        }
    }
}

fun callNumber(context: Context, number: String) {
    val intent = Intent(Intent.ACTION_DIAL).apply {
        data = Uri.parse("tel:$number")
    }
    if (intent.resolveActivity(context.packageManager) != null) {
        startActivity(context, intent, null)
    }
}

fun sendEmail(context: Context, email: String) {
    val intent = Intent(Intent.ACTION_SENDTO).apply {
        data = Uri.parse("mailto:$email")
        putExtra(Intent.EXTRA_SUBJECT, "Emergency Assistance Needed")
    }
    if (intent.resolveActivity(context.packageManager) != null) {
        startActivity(context, intent, null)
    }
}

fun findNearestHospital(context: Context) {
    val intent = Intent(Intent.ACTION_VIEW).apply {
        data = Uri.parse("geo:0,0?q=hospitals near me")
    }
    if (intent.resolveActivity(context.packageManager) != null) {
        startActivity(context, intent, null)
    }
}
