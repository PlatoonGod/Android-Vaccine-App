// Vaccine.kt
// Data class for representing a vaccine

package com.example.vaccineapp

data class Vaccine(
    val ageGroup: String,
    val name: String,
    val checked: Boolean = false
)
