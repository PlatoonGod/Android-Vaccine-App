package com.example.vaccineapp

// NewsAPI Key: 6168c6854ea54fe0bfbf361184797849

import io.ktor.client.HttpClient
import io.ktor.client.call.receive
import io.ktor.client.features.json.JsonFeature
import io.ktor.client.features.json.serializer.KotlinxSerializer
import io.ktor.client.request.get
import io.ktor.client.request.parameter
import io.ktor.client.statement.HttpResponse
import kotlinx.serialization.Serializable


// Data classes to match the JSON structure returned by NewsAPI
@Serializable
data class NewsResponse(val status: String, val totalResults: Int, val articles: List<NewsArticle>)

@Serializable
data class NewsArticle(val title: String, val description: String?, val url: String) // Making description nullable (String?) allows the JSON parser to correctly handle null values without throwing an exception.

class NewsRepository {
    private val client = HttpClient {
        install(JsonFeature) {
            serializer = KotlinxSerializer(kotlinx.serialization.json.Json {
                ignoreUnknownKeys = true // This helps to ignore JSON fields that are not required
            })
        }
    }

    suspend fun getNewsArticles(): List<NewsArticle> {
        val url = "https://newsapi.org/v2/top-headlines"
        val httpResponse: HttpResponse = client.get(url) {
            parameter("apiKey", "6168c6854ea54fe0bfbf361184797849")
            parameter("category", "health")
            parameter("q", "vaccine")
        }
        val newsResponse: NewsResponse = httpResponse.receive()
        return newsResponse.articles
    }
}
