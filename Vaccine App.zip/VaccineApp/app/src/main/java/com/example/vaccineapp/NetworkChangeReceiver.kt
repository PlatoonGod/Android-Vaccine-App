// NetworkChangeReceiver.kt
// BroadcastReceiver for handling network connectivity changes

package com.example.vaccineapp

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class NetworkChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == ConnectivityManager.CONNECTIVITY_ACTION) {
            val isConnected = isNetworkAvailable(context)
            val notificationTitle = if (isConnected) {
                "Network Connected"
            } else {
                "Network Disconnected"
            }
            val notificationContent = if (isConnected) {
                "You are connected to the internet."
            } else {
                "You have lost internet connectivity."
            }

            if (MainActivity.canSendNotifications) {
                sendNetworkNotification(context, notificationTitle, notificationContent)
            }
        }
    }

    private fun isNetworkAvailable(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = connectivityManager.activeNetwork
        val networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork)
        return networkCapabilities != null && networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    @SuppressLint("MissingPermission")
    private fun sendNetworkNotification(context: Context, title: String, content: String) {
        val builder = NotificationCompat.Builder(context, "CHANNEL_ID")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(content)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        with(NotificationManagerCompat.from(context)) {
            notify(2, builder.build())
        }
    }
}
