package com.example.vaccineapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavController

class ProfileActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val profileViewModel = ViewModelProvider(this).get(ProfileViewModel::class.java)
        setContent {
            ProfileForm(profileViewModel, navController = null) // Pass null as navController since it's not needed here
        }
    }

    companion object {
        fun newIntent(context: Context): Intent {
            return Intent(context, ProfileActivity::class.java)
        }
    }
}

@Composable
fun ProfileForm(viewModel: ProfileViewModel, navController: NavController?) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "Please enter your details", fontSize = 24.sp, modifier = Modifier.padding(bottom = 16.dp))

        // Name form field
        TextField(
            value = viewModel.name.value,
            onValueChange = viewModel::onNameChange,
            label = { Text("Name") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Surname form field
        TextField(
            value = viewModel.surname.value,
            onValueChange = viewModel::onSurnameChange,
            label = { Text("Surname") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Age form field
        TextField(
            value = viewModel.age.value,
            onValueChange = viewModel::onAgeChange,
            label = { Text("Age") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Gender switch field
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text(text = "Male")
            Spacer(modifier = Modifier.width(8.dp))
            Switch(
                checked = viewModel.gender.value,
                onCheckedChange = viewModel::onGenderChange
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "Female")
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Emergency contact form field
        TextField(
            value = viewModel.emergencyContact.value,
            onValueChange = viewModel::onEmergencyContactChange,
            label = { Text("Emergency Contact") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Country form field (grayed out and read-only)
        TextField(
            value = viewModel.country.value,
            onValueChange = { /* Read-only field */ },
            label = { Text("Country") },
            readOnly = true,
            enabled = false,  // Makes the field grayed out
            placeholder = { Text("UK") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        // SUBMIT button
        Button(onClick = {
            viewModel.saveUserInputs(
                viewModel.name.value,
                viewModel.surname.value,
                viewModel.age.value,
                viewModel.gender.value,
                viewModel.emergencyContact.value
            )
            navController?.navigate("home")  // Navigate back to home if navController is not null
        }) {
            Text("Submit")
        }
    }
}

/*
@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    val viewModel = ProfileViewModel()
    ProfileForm(viewModel = viewModel, navController = null)
}
*/
