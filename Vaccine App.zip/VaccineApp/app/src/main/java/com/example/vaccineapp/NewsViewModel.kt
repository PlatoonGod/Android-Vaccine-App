package com.example.vaccineapp

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class NewsViewModel(private val newsRepository: NewsRepository): ViewModel() {
    private val _newsArticles = MutableStateFlow<List<NewsArticle>>(emptyList())
    val newsArticles: StateFlow<List<NewsArticle>> = _newsArticles

    init {
        fetchNews()
    }

    private fun fetchNews() {
        viewModelScope.launch {
            val articles = newsRepository.getNewsArticles()
            _newsArticles.value = articles
        }
    }
}
