// MainActivity.kt
// Main entry point of the app, handles UI initialization and broadcast receiver setup

package com.example.vaccineapp

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Article
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {
    private lateinit var networkChangeReceiver: BroadcastReceiver

    companion object {
        private const val NOTIFICATION_PERMISSION_REQUEST_CODE = 1
        var canSendNotifications = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        checkNotificationPermission()
        val dataStoreManager = DataStoreManager(this)
        setContent {
            val profileViewModel: ProfileViewModel = viewModel(factory = ProfileViewModelFactory(dataStoreManager))
            val vaccinesViewModel: VaccinesViewModel = viewModel(factory = VaccinesViewModelFactory(dataStoreManager))

            LaunchedEffect(vaccinesViewModel) {
                vaccinesViewModel.setSendNotificationFunction { title, content ->
                    sendNotification(this@MainActivity, title, content)
                }
            }

            MainScreen(profileViewModel, vaccinesViewModel)
        }

        // Initialize the NetworkChangeReceiver
        networkChangeReceiver = NetworkChangeReceiver()
        val intentFilter = IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION)
        registerReceiver(networkChangeReceiver, intentFilter)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(networkChangeReceiver)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "MyChannel"
            val descriptionText = "My channel description"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel("CHANNEL_ID", name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun checkNotificationPermission() {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            canSendNotifications = true
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST_CODE)
        }
    }

    @SuppressLint("MissingPermission")
    fun sendNotification(context: Context, title: String, content: String) {
        if (canSendNotifications) {
            val builder = NotificationCompat.Builder(context, "CHANNEL_ID")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(content)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)

            with(NotificationManagerCompat.from(context)) {
                notify(1, builder.build())
            }
        } else {
            checkNotificationPermission()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == NOTIFICATION_PERMISSION_REQUEST_CODE) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                canSendNotifications = true
                sendNotification(this, "Permission Granted", "Now you can receive notifications")
            } else {
                canSendNotifications = false
            }
        }
    }
}

@Composable
fun MainScreen(profileViewModel: ProfileViewModel, vaccinesViewModel: VaccinesViewModel) {
    val navController = rememberNavController()
    Scaffold(
        bottomBar = { BottomNavigationBar(navController) }
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            AppNavHost(profileViewModel, vaccinesViewModel, navController)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MyRowComposable(profileViewModel: ProfileViewModel, vaccinesViewModel: VaccinesViewModel, navController: NavController) {
    val checkedCount by vaccinesViewModel.getCheckedVaccinesCount().collectAsState(initial = 0)
    val requiredCount by vaccinesViewModel.getRequiredVaccinesCount(profileViewModel.age.value ?: "1").collectAsState(initial = 0)
    val vaccines by vaccinesViewModel.vaccines.collectAsState()
    val notifyForPerfectScore by vaccinesViewModel.notifyForPerfectScore.collectAsState()
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        stickyHeader {
            Box(modifier = Modifier.background(Color.White)) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    ) {
                        Text(text = "Jab Score: $checkedCount / $requiredCount", fontSize = 20.sp)
                        Spacer(modifier = Modifier.weight(1f))
                        ClickableText(
                            text = AnnotatedString("Settings"),
                            onClick = {
                                navController.navigate("settings")
                            }
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    ) {
                        Button(onClick = {
                            shareUserInfo(context, profileViewModel)
                        }) {
                            Text("Share Info")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Notify on perfect score")
                            Switch(
                                checked = notifyForPerfectScore,
                                onCheckedChange = {
                                    vaccinesViewModel.setNotifyForPerfectScore(it)
                                }
                            )
                        }
                    }
                }
            }
        }

        item {
            UserInfo(profileViewModel = profileViewModel)
        }

        items(vaccines) { vaccine ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${vaccine.ageGroup}: ${vaccine.name}",
                    modifier = Modifier.weight(1f)
                )
                Checkbox(
                    checked = vaccine.checked,
                    onCheckedChange = { checked ->
                        vaccinesViewModel.updateVaccineState(vaccine, checked)
                    }
                )
            }
        }
    }
}

@Composable
fun UserInfo(profileViewModel: ProfileViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(text = "Name: ${profileViewModel.name.value}")
        Text(text = "Surname: ${profileViewModel.surname.value}")
        Text(text = "Age: ${profileViewModel.age.value}")
        Text(text = "Gender: ${if (profileViewModel.gender.value) "Female" else "Male"}")
        Text(text = "Emergency Contact: ${profileViewModel.emergencyContact.value}")
        Text(text = "Country: ${profileViewModel.country.value}")
    }
}

fun shareUserInfo(context: Context, profileViewModel: ProfileViewModel) {
    val userInfo = """
        Name: ${profileViewModel.name.value}
        Surname: ${profileViewModel.surname.value}
        Age: ${profileViewModel.age.value}
        Gender: ${if (profileViewModel.gender.value) "Female" else "Male"}
        Emergency Contact: ${profileViewModel.emergencyContact.value}
        Country: ${profileViewModel.country.value}
    """.trimIndent()

    val shareIntent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_TEXT, userInfo)
        type = "text/plain"
    }
    val chooser = Intent.createChooser(shareIntent, "Share User Info")
    context.startActivity(chooser)
}

@Composable
fun AppNavHost(profileViewModel: ProfileViewModel, vaccinesViewModel: VaccinesViewModel, navController: NavController) {
    NavHost(navController = navController as NavHostController, startDestination = "home") {
        composable("home") { MyRowComposable(profileViewModel, vaccinesViewModel, navController) }
        composable("settings") { ProfileForm(profileViewModel, navController) }
        composable("news") {
            val newsRepository = NewsRepository()
            val factory = NewsViewModelFactory(newsRepository)
            val newsViewModel: NewsViewModel = viewModel(factory = factory)
            NewsScreen(newsViewModel)
        }
        composable("emergency") { EmergencyScreen(profileViewModel) }
    }
}

@Composable
fun BottomNavigationBar(navController: NavController) {
    val items = listOf(
        Screen.Home,
        Screen.News,
        Screen.Emergency
    )
    NavigationBar {
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route
        items.forEach { screen ->
            NavigationBarItem(
                icon = { Icon(screen.icon, contentDescription = null) },
                label = { Text(screen.title) },
                selected = currentRoute == screen.route,
                onClick = {
                    if (currentRoute != screen.route) {
                        navController.navigate(screen.route) {
                            navController.graph.startDestinationRoute?.let { route ->
                                popUpTo(route) {
                                    saveState = true
                                }
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    } else {
                        navController.popBackStack()
                        navController.navigate(screen.route)
                    }
                }
            )
        }
    }
}

// Define the screens corresponding to the navigation items
sealed class Screen(val route: String, val icon: ImageVector, val title: String) {
    object Home : Screen("home", Icons.Filled.Home, "Home")
    object News : Screen("news", Icons.AutoMirrored.Filled.Article, "News")
    object Emergency : Screen("emergency", Icons.Filled.LocalHospital, "Emergency")
}
