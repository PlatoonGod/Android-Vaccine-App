package com.example.vaccineapp

import android.content.ContentValues
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class UpdateProfileActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            UpdateProfileScreen()
        }
    }

    @Composable
    fun UpdateProfileScreen() {
        var name by remember { mutableStateOf("") }
        var surname by remember { mutableStateOf("") }
        var age by remember { mutableStateOf("") }
        var gender by remember { mutableStateOf(false) }
        var emergencyContact by remember { mutableStateOf("") }
        var country by remember { mutableStateOf("") }
        val context = LocalContext.current

        Column(modifier = Modifier.padding(16.dp)) {
            TextField(value = name, onValueChange = { name = it }, label = { Text("Name") })
            TextField(value = surname, onValueChange = { surname = it }, label = { Text("Surname") })
            TextField(value = age, onValueChange = { age = it }, label = { Text("Age") })
            TextField(value = emergencyContact, onValueChange = { emergencyContact = it }, label = { Text("Emergency Contact") })
            TextField(value = country, onValueChange = { country = it }, label = { Text("Country") })
            Row {
                Text("Gender: ")
                Text(if (gender) "Female" else "Male")
                Spacer(modifier = Modifier.width(8.dp))
                Button(onClick = { gender = !gender }) {
                    Text(if (gender) "Switch to Male" else "Switch to Female")
                }
            }
            Button(onClick = {
                val values = ContentValues().apply {
                    put(UserProfileDbHelper.COLUMN_NAME, name)
                    put(UserProfileDbHelper.COLUMN_SURNAME, surname)
                    put(UserProfileDbHelper.COLUMN_AGE, age)
                    put(UserProfileDbHelper.COLUMN_GENDER, if (gender) 1 else 0)
                    put(UserProfileDbHelper.COLUMN_EMERGENCY_CONTACT, emergencyContact)
                    put(UserProfileDbHelper.COLUMN_COUNTRY, country)
                }
                context.contentResolver.insert(UserProfileContentProvider.CONTENT_URI, values)
            }) {
                Text("Save")
            }
        }
    }
}
