// NewsActivity.kt
// Handles the UI and functionality for News fetching and displaying news

// NOTE: NEWS-API WAS USED FOR THE COLLECTION OF HEADLINES RELATING TO VACCINES

package com.example.vaccineapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider

class NewsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val newsRepository = NewsRepository()
        val factory = NewsViewModelFactory(newsRepository)
        val newsViewModel = ViewModelProvider(this, factory).get(NewsViewModel::class.java)
        setContent {
            NewsScreen(newsViewModel)
        }
    }
}

@Composable
fun NewsScreen(newsViewModel: NewsViewModel) {
    val newsArticles by newsViewModel.newsArticles.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(newsArticles) { article ->
            NewsArticleItem(article)
        }
    }
}

@Composable
fun NewsArticleItem(article: NewsArticle) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = article.title,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Text(text = article.description ?: "No description available.")
    }
}
