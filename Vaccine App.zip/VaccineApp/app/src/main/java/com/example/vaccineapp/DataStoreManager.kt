// DataStoreManager.kt
// Manages the data storage and retrieval using DataStore

package com.example.vaccineapp

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "user_settings")

class DataStoreManager(private val context: Context) {

    companion object {
        val NAME_KEY = stringPreferencesKey("name")
        val SURNAME_KEY = stringPreferencesKey("surname")
        val AGE_KEY = stringPreferencesKey("age")
        val GENDER_KEY = booleanPreferencesKey("gender")
        val EMERGENCY_CONTACT_KEY = stringPreferencesKey("emergency_contact")
        val COUNTRY_KEY = stringPreferencesKey("country")
        val VACCINE_STATES_KEY = stringPreferencesKey("vaccine_states")
    }

    val name: Flow<String?> = context.dataStore.data.map { preferences ->
        preferences[NAME_KEY]
    }

    val surname: Flow<String?> = context.dataStore.data.map { preferences ->
        preferences[SURNAME_KEY]
    }

    val age: Flow<String?> = context.dataStore.data.map { preferences ->
        preferences[AGE_KEY]
    }

    val gender: Flow<Boolean?> = context.dataStore.data.map { preferences ->
        preferences[GENDER_KEY]
    }

    val emergencyContact: Flow<String?> = context.dataStore.data.map { preferences ->
        preferences[EMERGENCY_CONTACT_KEY]
    }

    val country: Flow<String?> = context.dataStore.data.map { preferences ->
        preferences[COUNTRY_KEY]
    }

    suspend fun saveUserInputs(name: String, surname: String, age: String, gender: Boolean, emergencyContact: String) {
        context.dataStore.edit { preferences ->
            preferences[NAME_KEY] = name
            preferences[SURNAME_KEY] = surname
            preferences[AGE_KEY] = age
            preferences[GENDER_KEY] = gender
            preferences[EMERGENCY_CONTACT_KEY] = emergencyContact
            preferences[COUNTRY_KEY] = "UK" // Assuming country is always "UK"
        }
    }

    suspend fun saveVaccineStates(vaccines: List<Vaccine>) {
        context.dataStore.edit { preferences ->
            val states = vaccines.joinToString(separator = ";") { "${it.ageGroup},${it.name},${it.checked}" }
            preferences[VACCINE_STATES_KEY] = states
        }
    }

    fun loadVaccineStates(defaultVaccines: List<Vaccine>): Flow<List<Vaccine>> {
        return context.dataStore.data.map { preferences ->
            preferences[VACCINE_STATES_KEY]?.split(";")?.map { state ->
                val (ageGroup, name, checked) = state.split(",")
                Vaccine(ageGroup, name, checked.toBoolean())
            } ?: defaultVaccines
        }
    }
}
