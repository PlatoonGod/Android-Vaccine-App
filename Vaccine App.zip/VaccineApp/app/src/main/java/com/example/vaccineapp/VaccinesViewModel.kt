// VaccinesViewModel.kt
// ViewModel for managing the list of vaccines, tracking completion, and handling notifications

package com.example.vaccineapp

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class VaccinesViewModel(private val dataStoreManager: DataStoreManager) : ViewModel() {
    private val _vaccines = MutableStateFlow<List<Vaccine>>(emptyList())
    val vaccines: StateFlow<List<Vaccine>> get() = _vaccines
    val notifyForPerfectScore = MutableStateFlow(false)

    init {
        loadVaccines()
    }

    private fun loadVaccines() {
        val defaultVaccines = listOf(
            Vaccine("1 year old", "Hib/MenC vaccine"),
            Vaccine("1 year old", "MMR vaccine"),
            Vaccine("1 year old", "Pneumococcal vaccine"),
            Vaccine("1 year old", "MenB vaccine"),
            Vaccine("3 year old", "4-in-1 preschool vaccine"),
            Vaccine("13 year old", "HPV vaccine"),
            Vaccine("14 year old", "Td/IPV vaccine"),
            Vaccine("14 year old", "MenACWY vaccine"),
            Vaccine("15 year old", "flu vaccine"),
            Vaccine("65 year old", "flu Booster vaccine"),
            Vaccine("65 year old", "shingles vaccine"),
            Vaccine("79 year old", "shingles Booster vaccine")
        )
        viewModelScope.launch {
            dataStoreManager.loadVaccineStates(defaultVaccines).collect { savedVaccines ->
                _vaccines.value = savedVaccines
            }
        }
    }

    fun updateVaccineState(vaccine: Vaccine, checked: Boolean) {
        _vaccines.value = _vaccines.value.map {
            if (it.name == vaccine.name && it.ageGroup == vaccine.ageGroup) it.copy(checked = checked) else it
        }
        viewModelScope.launch {
            dataStoreManager.saveVaccineStates(_vaccines.value)
        }
    }

    private fun mapAgeToAgeGroups(age: String): List<String> {
        val ageInt = age.toIntOrNull() ?: return emptyList()
        return when {
            ageInt >= 15 -> listOf("1 year old", "3 year old", "13 year old", "14 year old", "15 year old")
            ageInt >= 14 -> listOf("1 year old", "3 year old", "13 year old", "14 year old")
            ageInt >= 13 -> listOf("1 year old", "3 year old", "13 year old")
            ageInt >= 3 -> listOf("1 year old", "3 year old")
            ageInt >= 1 -> listOf("1 year old")
            else -> emptyList()
        }
    }

    fun getCheckedVaccinesCount(): Flow<Int> {
        return vaccines.map { it.count { vaccine -> vaccine.checked } }
    }

    fun getRequiredVaccinesCount(age: String): Flow<Int> {
        val ageGroups = mapAgeToAgeGroups(age)
        return vaccines.map { it.count { vaccine -> vaccine.ageGroup in ageGroups } }
    }

    fun setNotifyForPerfectScore(enabled: Boolean) {
        notifyForPerfectScore.value = enabled
    }

    fun setSendNotificationFunction(sendNotification: (String, String) -> Unit) {
        viewModelScope.launch {
            combine(getCheckedVaccinesCount(), getRequiredVaccinesCount("15")) { checked, required ->
                if (checked == required && notifyForPerfectScore.value) {
                    sendNotification("Congratulations", "You have now taken all NHS recommended vaccines!")
                }
            }.collect()
        }
    }
}
